import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpXsrfTokenExtractor, HttpRequest, HttpHandler } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class InsertXsrfService implements HttpInterceptor {

  constructor( private xsrfTokenExtractor: HttpXsrfTokenExtractor) { }

  intercept(req:HttpRequest<any>, next:HttpHandler)  
  {
    let xsrfToken = this.xsrfTokenExtractor.getToken();
    if (req.method == "POST") {
      const authorizedRequest = req.clone({
      withCredentials: true,      
      headers: req.headers.set("X-XSRF-TOKEN", xsrfToken)     
      });    
      return next.handle(authorizedRequest);
      } else {
      next.handle(req);
    }
  }
}
